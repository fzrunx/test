<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * PDO 연결 생성 (← app/core/database.py)
 * PHP는 요청마다 새로 실행되므로 요청당 한 번만 연결한다.
 */
class Database
{
    public static function connect(array $cfg): PDO
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $cfg['host'],
            $cfg['port'],
            $cfg['name'],
            $cfg['charset']
        );

        return new PDO($dsn, $cfg['user'], $cfg['password'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // 오류를 예외로
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,                    // 진짜 prepared statement 사용
        ]);
    }
}
