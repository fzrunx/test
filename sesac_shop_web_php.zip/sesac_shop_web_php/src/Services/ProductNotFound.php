<?php
declare(strict_types=1);

namespace App\Services;

class ProductNotFound extends \RuntimeException
{
}