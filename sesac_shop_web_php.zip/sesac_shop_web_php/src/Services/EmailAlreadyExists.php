<?php
declare(strict_types=1);

namespace App\Services;

class EmailAlreadyExists extends \RuntimeException
{
}
