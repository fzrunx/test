<?php
declare(strict_types=1);

/**
 * MySQL 슬로우 쿼리 로그(여러 줄)를 한 줄 JSON으로 바꿔
 * logs/mysql_slow.jsonl 에 이어 붙인다.
 *
 * 와주 에이전트는 이 파일을 app.log 와 똑같은 방식(log_format: json)으로 읽으면 된다.
 * 이미 읽은 위치는 logs/.slowlog_offset 에 저장해서, 다음 실행 때 그 뒤부터만 읽는다.
 *
 * 실행: php tools/slowlog_to_json.php
 * Windows 작업 스케줄러에 1분마다 실행되도록 등록해서 쓴다.
 */

const SLOW_LOG_PATH = 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Data\\DESKTOP-PE6IN27-slow.log';

$root       = dirname(__DIR__);
$outputPath = $root . '/logs/mysql_slow.jsonl';
$offsetPath = $root . '/logs/.slowlog_offset';

if (!is_file(SLOW_LOG_PATH)) {
    fwrite(STDERR, "슬로우 로그 파일을 찾을 수 없습니다: " . SLOW_LOG_PATH . "\n");
    exit(1);
}

$fileSize = filesize(SLOW_LOG_PATH);
$offset   = is_file($offsetPath) ? (int) trim((string) file_get_contents($offsetPath)) : 0;

// 파일이 교체되었거나(FLUSH SLOW LOGS 등) 작아졌으면 처음부터 다시 읽는다.
if ($offset > $fileSize) {
    $offset = 0;
}

$handle = fopen(SLOW_LOG_PATH, 'rb');
if ($handle === false) {
    fwrite(STDERR, "슬로우 로그 파일을 열 수 없습니다 (권한 확인)\n");
    exit(1);
}
fseek($handle, $offset);
$newContent = stream_get_contents($handle);
fclose($handle);

file_put_contents($offsetPath, (string) $fileSize);

if ($newContent === false || trim($newContent) === '') {
    exit(0);   // 새로 쌓인 내용이 없으면 조용히 끝낸다
}

// "# Time: ..." 줄을 기준으로 한 건씩 나눈다.
$blocks = preg_split('/^(?=# Time: )/m', $newContent);
$lines  = [];

foreach ($blocks as $block) {
    $block = trim($block);
    if ($block === '' || strpos($block, '# Time:') !== 0) {
        continue;   // 로그 맨 앞의 서버 시작 메시지 등은 건너뛴다
    }

    if (!preg_match('/^# Time: (\S+)/m', $block, $m)) {
        continue;
    }
    $time = $m[1];

    if (!preg_match('/^# User@Host:\s*(\S+?)\[\S*\]\s*@\s*(\S+)\s*\[([^\]]*)\]/m', $block, $m)) {
        continue;
    }
    $dbUser   = $m[1];
    $dbHost   = $m[2] !== '' ? $m[2] : null;
    $clientIp = $m[3] !== '' ? $m[3] : null;

    if (!preg_match('/^# Query_time:\s*([\d.]+)\s+Lock_time:\s*([\d.]+)\s+Rows_sent:\s*(\d+)\s+Rows_examined:\s*(\d+)/m', $block, $m)) {
        continue;
    }
    $queryTimeMs   = round(((float) $m[1]) * 1000, 2);
    $rowsSent      = (int) $m[3];
    $rowsExamined  = (int) $m[4];

    // "SET timestamp=...;" 다음 줄부터가 실제 SQL이다.
    $sql = null;
    if (preg_match('/^SET timestamp=\d+;\s*\n(.*)$/ms', $block, $m)) {
        $sql = trim(preg_replace('/\s+/', ' ', $m[1]));
    }

    // Prepare / Close stmt / Quit 같은 내부 관리 명령은 잡음이라 건너뛴다.
    if ($sql === null || $sql === '' || strpos($sql, '# administrator command:') === 0) {
        continue;
    }

    $lines[] = json_encode([
        'timestamp'     => $time,
        'db_user'       => $dbUser,
        'db_host'       => $dbHost,
        'client_ip'     => $clientIp,
        'query_time_ms' => $queryTimeMs,
        'rows_sent'     => $rowsSent,
        'rows_examined' => $rowsExamined,
        'sql'           => mb_strcut($sql, 0, 2000, 'UTF-8'),
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}

if ($lines === []) {
    exit(0);
}

file_put_contents($outputPath, implode("\n", $lines) . "\n", FILE_APPEND | LOCK_EX);
echo count($lines) . "건 변환함\n";