<?php
// 개발용 PHP 내장 서버 라우터 (Apache의 .htaccess 역할). 배포 때는 쓰지 않는다.
// 실행: php -S 127.0.0.1:8001 -t public dev-router.php
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (strpos($path, '/api/v1/') === 0) {
    require __DIR__ . '/public/api-v1/index.php';
    return true;
}
if (strpos($path, '/api/') === 0) {
    require __DIR__ . '/public/api/index.php';
    return true;
}
return false;   // 나머지는 내장 서버가 public/ 의 파일을 그대로 처리